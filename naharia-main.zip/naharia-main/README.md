- 👋 Hi, I’m @nahariaprateek
- 👀 I’m interested in solving business problems 
- 🌱 I’m currently learning business analytics
- 💞️ I’m looking to collaborate on data driven business solutions
- 📫 Email me on nahariaprateek@gmail.com

<!---
nahariaprateek/nahariaprateek is a ✨ special ✨ repository because its `README.md` (this file) appears on your GitHub profile.
You can click the Preview link to take a look at your changes.
--->
